### TODO

* Allow plugin files with multiple underscores in the name.
* Per plugin TravisCI badge
* Jenkins job
* NRPE
* ...

